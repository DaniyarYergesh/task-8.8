fun main(){

    val myLambda: (Int) -> Unit = {
        println(it)
    }

    println(4.powerOf(3)) //task1
    3.powerOf2(6, myLambda) //task2
    true.displayTypeInfo() //task3
    DataType.DoubleType(4.0).displayTypeInfo2() //task4
    DataType.UnitType().displayTypeInfo2()
}

//task 1
fun Int.powerOf(power: Int): Double {
    return Math.pow(this.toDouble(), power.toDouble())
}

//task2
fun Int.powerOf2(power: Int, myLambda1: (Int) -> Unit) {
    val result = Math.pow(this.toDouble(), power.toDouble()).toInt()
    myLambda1(result)
}

//task3
fun <T> T.displayTypeInfo(){
    if (this is Int) {
        println("это Int")
    } else if (this is String){
        println("это String")
    }else{
        println("тип у $this неизвестен")
    }
}

//task4
fun <T> T.displayTypeInfo2(){
    when(this){
        is Int -> println("это Int")
        is String -> println("это String")

        is DataType.DoubleType -> println("это DoubleType со значением ${value}")
        is DataType.UnitType -> println("это Unit")
        else -> println("тип у $this неизвестен")
    }
}

sealed class DataType{
    class DoubleType(val value: Double): DataType()
    class UnitType: DataType()
}
